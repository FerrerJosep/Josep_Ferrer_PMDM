package com.ieseljust.pmdm.whatsdam.viewmodel

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ieseljust.pmdm.whatsdam.Message
import com.ieseljust.pmdm.whatsdam.R
import java.text.SimpleDateFormat
import java.util.Date


class MissatgeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {

    // Necessitem la vista per a l'hora i el text del missatge
    // Obtenemos referencias a las vistas que vamos a utilizar en el ViewHolder
    val data = itemView.findViewById(R.id.msg_me_timestamp) as TextView
    val text = itemView.findViewById(R.id.msg_text) as TextView

    init {
        // Asignamos este ViewHolder como escuchador de clics en su vista principal (itemView)
        itemView.setOnClickListener(this)
    }

    // Enllacem les dades del missatge amb la vista
    // Vinculamos los datos del mensaje con la vista
    fun bind(missatge: Message, eventListener: (Message, View) -> Boolean) {
        // Configuramos el texto del mensaje
        text.text = missatge.text

        // Para la fecha, mostramos la hora actual
        // Utilizamos SimpleDateFormat y Date para esto
        val dateFormat = SimpleDateFormat("HH:mm")
        val horaActual = Date()
        data.text = dateFormat.format(horaActual)

        // Configuramos un OnLongClickListener para la vista del mensaje
        itemView.setOnLongClickListener {
            // Llamamos a la función del event listener pasándole el mensaje y la vista
            eventListener(missatge, itemView)
        }
    }

    // Método requerido por View.OnClickListener, aunque no se utiliza en este caso
    override fun onClick(v: View?) {
        // Este método podría implementarse para manejar clics cortos en el mensaje si es necesario
    }
}

