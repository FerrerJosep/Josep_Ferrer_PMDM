package com.ieseljust.pmdm.whatsdam.viewmodel

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.ieseljust.pmdm.whatsdam.Message
import com.ieseljust.pmdm.whatsdam.R
import java.text.SimpleDateFormat
import java.util.Date


class MissatgeAltreViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    // Necessitem la vista per a l'hora i el text del missatge
    // Obtenemos referencias a las vistas que vamos a utilizar en el ViewHolder
    val data = itemView.findViewById(R.id.msg_other_timestamp) as TextView
    val text = itemView.findViewById(R.id.msg_other_text) as TextView
    val user = itemView.findViewById(R.id.msg_text_usuari) as TextView
    val reply = itemView.findViewById(R.id.button_reply) as FloatingActionButton


    // Enllacem les dades del missatge amb la vista del ViewHolder
    fun bind(msg: Message, eventLister: (Message, View) -> Unit) {
        // Configuramos el texto del mensaje y del usuario
        text.text = msg.text
        user.text = msg.username

        // Para la fecha, mostramos la hora actual
        // Utilizamos SimpleDateFormat y Date para esto
        val dateFormat = SimpleDateFormat("HH:mm")
        val horaActual = Date()
        data.text = dateFormat.format(horaActual)

        // Configuramos un OnClickListener para el botón de respuesta
        reply.setOnClickListener {
            // Llamamos a la función del event listener pasándole el mensaje y la vista
            eventLister(msg, itemView)
        }
    }
}
