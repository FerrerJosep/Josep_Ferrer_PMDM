package com.ieseljust.pmdm.whatsdam.repository

import com.ieseljust.pmdm.whatsdam.Message
import com.ieseljust.pmdm.whatsdam.Messages

class MessagesRepository private constructor() { // Constructor privat

    // Propietats del repositori

    val username = "Casc Fosc"       // Nombre del usuario
    val server = "192.168.1.1"    // Dirección IP del servidor

    // Implementacio del Singleton
    companion object {
        // Referencia a la propia instancia de la clase
        private var INSTANCE: MessagesRepository? = null

        // Método para obtener la referencia a esta instancia
        fun getInstance(): MessagesRepository {
            if (INSTANCE == null) {
                INSTANCE = MessagesRepository()
            }
            return INSTANCE!!
        }
    }

    // Métodos que ofrece este API del repositorio:

    // Obtiene la lista de mensajes
    fun getMessages() = Messages.getMessages()

    // Obtiene la cantidad de mensajes
    fun getNumMessages() = Messages.getNumMessages()

    // Añade un mensaje a la lista
    fun add(msg: Message) = Messages.add(msg)

    // Elimina un mensaje de la lista
    fun deleteMessage(msg: Message) {
        return Messages.deleteMessage(msg)
    }
}
