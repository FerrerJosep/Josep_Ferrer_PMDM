package com.ieseljust.pmdm.whatsdam

import java.io.Serializable

// Definim la data class Contacte
data class Message(
    val username: String,
    var text: String,
): Serializable

object Messages {
    private var _messages: ArrayList<Message>


    init {
        _messages = arrayListOf<Message>(
            Message("Casc Fosc", "Bé Rei Roland, està disposat a donar-nos la contrassenya per accedir al planeta Druidia?"),
            Message("Rei Roland", "Pel bé de la meua filla, us la diré"),
            Message("Rei Roland", "La contrassenya és... 1, 2, 3..."),
            Message("Casc Fosc", "1, 2, 3..."),
            Message("Rei Roland", "4 i 5"),
            Message("Casc Fosc", "4 i 5... Es la contrassenya que qualsevol idiota posaria a les seues maletes!"),
            Message("Casc Fosc", "President Scroob, ja tenim la clau d'accés!"),
            Message("Scroob", "Perfecte. Quina és?"),
            Message("Casc Fosc", "1 2 3 4 5"),
            Message("Scroob", "Fascinant! Es la mateixa combinació que tinc a les meues maletes!")

        )
    }

    // Métodos para agregar mensajes
    fun add(username: String, text: String) {
        _messages.add(Message(username = username, text = text))
    }

    fun add(msg: Message) = _messages.add(msg)

    // Métodos para obtener mensajes y su cantidad
    fun getMessages() = _messages

    fun getNumMessages() = _messages.size

    // Función para eliminar un mensaje (modifica el texto del mensaje)
    fun deleteMessage(msg: Message) {
        msg.text = "El mensaje se ha borrado"
    }


}