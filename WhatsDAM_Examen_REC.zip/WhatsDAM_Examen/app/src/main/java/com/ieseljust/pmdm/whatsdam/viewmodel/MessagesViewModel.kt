package com.ieseljust.pmdm.whatsdam.viewmodel

import android.app.Application
import android.util.Log
import android.view.View
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.ieseljust.pmdm.whatsdam.Message
import com.ieseljust.pmdm.whatsdam.repository.MessagesRepository

class MessagesViewModel(application: Application) : AndroidViewModel(application) {

    /* Propiedades del ViewModel */

    // MutableLiveData para el adaptador del RecyclerView
    private val _adaptador = MutableLiveData<MissatgesAdapter>().apply {
        value = MissatgesAdapter(
            { msg: Message, v: View -> ReplyManager(msg.text, msg.username) },
            { msg: Message, v: View -> MissatgeLongClicked(msg, v) }
        )
    }
    val adaptador: MutableLiveData<MissatgesAdapter> = _adaptador

    // MutableLiveData para el índice del último mensaje insertado
    private val _latestInserted = MutableLiveData<Int>().apply {
        value = 0
    }
    val latestInserted: MutableLiveData<Int> = _latestInserted

    // MutableLiveData para el mensaje de respuesta
    private val _replyMessage = MutableLiveData<String>().apply {
        value = ""
    }
    val replyMessage: MutableLiveData<String> = _replyMessage

    // Referencia al Repositorio
    var repository = MessagesRepository.getInstance()


    // Función para manejar la respuesta a un mensaje
    private fun ReplyManager(msg: String, nomUser: String) {
        Log.d("ReplyButton", "Responent: $msg")

        _replyMessage.value = "Resposta a $nomUser\n $msg "
    }

    // Función para agregar un mensaje al repositorio y notificar al adaptador
    public fun addMessage(msg: Message) {
        // Agregamos un mensaje a través de la instancia del repositorio
        repository.add(msg)
        _latestInserted.value = repository.getNumMessages() - 1
        _adaptador.value?.notifyItemInserted(latestInserted.value ?: 0)

        // No hacemos scroll aquí, se espera que la vista lo maneje.
    }



    // Función para manejar el evento de clic largo en un mensaje
    private fun MissatgeLongClicked(message: Message, v: View): Boolean {
        val index = MessagesRepository.getInstance().deleteMessage(message)
        adaptador.value?.notifyDataSetChanged()
        return true
    }
}
