package com.ieseljust.pmdm.whatsdam.viewmodel

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ieseljust.pmdm.whatsdam.Message
import com.ieseljust.pmdm.whatsdam.R
import com.ieseljust.pmdm.whatsdam.repository.MessagesRepository

class MissatgesAdapter(
    val clickListener: (Message, View) -> Unit,
    val clickLongListener: (Message, View) -> Boolean
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    // Constants per al tipus de missatge
    private val MISSATGE_D_USUARI = 1
    private val MISSATGE_D_ALTRE = 2

    // Referencia al repositori
    val repository = MessagesRepository.getInstance()

    // onCreateViewHolder se llama cuando se crea un nuevo ViewHolder.
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        // Obtenemos el LayoutInflater
        val inflater = LayoutInflater.from(parent.context)

        // Según el tipo de vista, inflamos y creamos el ViewHolder correspondiente.
        return when (viewType) {
            MISSATGE_D_USUARI -> {
                val vista = inflater.inflate(R.layout.my_msg_viewholder, parent, false)
                MissatgeViewHolder(vista)
            }
            MISSATGE_D_ALTRE -> { // MISSATGE_D_ALTRE
                val vista = inflater.inflate(R.layout.other_msg_viewholder, parent, false)
                MissatgeAltreViewHolder(vista)
            }
            else -> throw IllegalArgumentException("Vista desconeguda")
        }
    }

    // getItemCount devuelve el número total de elementos en el conjunto de datos.
    override fun getItemCount(): Int {
        return repository.getNumMessages()
    }

    // onBindViewHolder se llama cuando se vinculan datos a un ViewHolder.
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        // Distinguir según el tipo de vista y llamar al método bind correspondiente.
        if (getItemViewType(position) === MISSATGE_D_USUARI) {
            (holder as MissatgeViewHolder).bind(repository.getMessages()[position], clickLongListener)
        } else {
            (holder as MissatgeAltreViewHolder).bind(repository.getMessages()[position], clickListener)
        }
    }

    // getItemViewType determina el tipo de vista según la posición en el conjunto de datos.
    override fun getItemViewType(pos: Int): Int {
        val message = repository.getMessages()[pos]
        return if (message.username == repository.username) {
            MISSATGE_D_USUARI
        } else {
            MISSATGE_D_ALTRE
        }
    }
}




